﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using TrabalhoAcoes.Repositorio;
using TrabalhoAcoes.Dominio.Repositorio;
using TrabalhoAcoes.Dominio.Entidades;

namespace TrabalhoAcoes.Repositorio.Test
{
    [TestClass]
    public class AcaoRepositorioTeste
    {
        [TestMethod]
        public void InserirAcaoTeste()
        {

            Acao acao = new Acao()
            {
                Id = Guid.NewGuid(),
                Nome = "Acao 1",
            };

            AcaoRepositorio acaoRepositorio = new AcaoRepositorio();

            try
            {
                acaoRepositorio.Inserir(acao);
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

namespace TrabalhoAcoes.Dominio
{
    public class Base
    {
        public Guid Id { get; set; }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrabalhoAcoes.Dominio.Entidades;

namespace TrabalhoAcoes.Dominio.Repositorio
{
    public interface IAcaoRepositorio
    {
        Guid Inserir(Acao acao);
        Guid Alterar(Acao acao);
        Acao Selecionar(Guid Id);
        void Excluir(Guid Id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TrabalhoAcoes.Aplicacao.DTO;
using TrabalhoAcoes.Models;

namespace TrabalhoAcoes.Aplicacao.Adapter
{
    public class AcaoAdapter
    {
        public static Acao ParaDomain(AcaoDTO acao)
        {
            return new Acao()
            {
                Id = acao.Id,
                Nome = acao.Nome
            };
        }

        public static AcaoDTO ParaDto(Acao acao)
        {
            return new AcaoDTO()
            {
                Id = acao.Id,
                Nome = acao.Nome
            };
        }
    }
}
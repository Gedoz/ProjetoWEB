﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TrabalhoAcoes.Aplicacao.Adapter;
using TrabalhoAcoes.Aplicacao.DTO;
using TrabalhoAcoes.Dominio.Entidades;
using TrabalhoAcoes.Dominio.Repositorio;

namespace TrabalhoAcoes.Aplicacao
{
    public class AcaoAplicacao
    {
        private IAcaoRepositorio acaoRepositorio;

        public AcaoAplicacao(IAcaoRepositorio acaoRepositorio)
        {
            this.acaoRepositorio = acaoRepositorio;
        }

        public void Excluir(Guid id)
        {
            if (id == Guid.Empty)
            {
                throw new ApplicationException("Id não informado");
            }

            this.acaoRepositorio.Excluir(id);
        }

        public AcaoDTO Procurar(Guid id)
        {
            if (id == Guid.Empty)
            {
                throw new ApplicationException("Id nao informado");
            }

            Acao acao = this.acaoRepositorio.Selecionar(id);

            return AcaoAdapter.ParaDto(acao);
        }

        public Guid Alterar(AcaoDTO acao)
        {
            Acao action = AcaoAdapter.ParaDomain(acao);

            if (string.IsNullOrEmpty(action.Nome))
            {
                throw new ApplicationException("Nome não informado");
            }

            this.acaoRepositorio.Alterar(action);

            return action.Id;
        }

        public Guid Inserir(AcaoDTO acao)
        {
            Acao action = AcaoAdapter.ParaDomain(acao);
            action.Id = Guid.NewGuid();

            if (string.IsNullOrEmpty(action.Nome))
            {
                throw new ApplicationException("Nome não informado");
            }

            this.acaoRepositorio.Inserir(action);

            return action.Id;
        }
    }
}
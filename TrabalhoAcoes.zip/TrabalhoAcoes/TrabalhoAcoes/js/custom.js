﻿function AlertaVoluntario() {
    alert("Parabéns, você se candidatou para essa ação!!");
}

function AlertaTemp() {
    alert("Impossivel realizar essa função!!");
}

function CadastroEfetuado() {
    alert("Cadastro efetuado com sucesso!!");
}
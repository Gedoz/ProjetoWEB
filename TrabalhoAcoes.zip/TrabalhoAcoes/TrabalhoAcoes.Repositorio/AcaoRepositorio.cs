﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.Sql; //bibliotecas para acessar o sql server
using System.Data.SqlClient; //bibliotecas para acessar o sql server

using TrabalhoAcoes.Dominio.Entidades;
using TrabalhoAcoes.Dominio.Repositorio;

namespace TrabalhoAcoes.Repositorio 
{
    public class AcaoRepositorio : IAcaoRepositorio
    {
        private string stringConexao;

        public AcaoRepositorio()
        {
            stringConexao = @"Server=NOTEJULIANO\SQLEXPRESS;Database=projweb;User Id=sa;Password = 123456; ";
        }

        public Guid Alterar(Acao acao)
        {
            using (SqlConnection conexao = new SqlConnection(stringConexao))
            {
                conexao.Open();
                using (SqlTransaction trans = conexao.BeginTransaction())
                {
                    try
                    {
                        SqlCommand comando = new SqlCommand();
                        comando.Connection = conexao;
                        comando.Transaction = trans;
                        comando.CommandText = "UPDATE Acao SET  Nome=@Nome" +
                                              "              WHERE Id=@Id ";

                        comando.Parameters.AddWithValue("Id", acao.Id);
                        comando.Parameters.AddWithValue("Nome", acao.Nome);
                        //comando.Parameters.AddWithValue("Preco", produto.Preco);
                        //comando.Parameters.AddWithValue("Quantidade", produto.Quantidade);

                        comando.ExecuteNonQuery();

                        trans.Commit();
                    }
                    catch (Exception ex)
                    {
                        trans.Rollback();
                    }
                }
            }
            return acao.Id;
        }

        public void Excluir(Guid id)
        {
            using (SqlConnection conexao = new SqlConnection(stringConexao))
            {
                conexao.Open();
                using (SqlTransaction trans = conexao.BeginTransaction())
                {
                    try
                    {
                        SqlCommand comando = new SqlCommand();
                        comando.Connection = conexao;
                        comando.Transaction = trans;
                        comando.CommandText = "DELETE FROM Acao WHERE Id=@Id ";

                        comando.Parameters.AddWithValue("Id", id);

                        comando.ExecuteNonQuery();

                        trans.Commit();
                    }
                    catch (Exception ex)
                    {
                        trans.Rollback();
                    }
                }
            }
        }

        public Guid Inserir(Acao acao)
        {
            using (SqlConnection conexao = new SqlConnection(stringConexao))
            {
                conexao.Open();
                using (SqlTransaction trans = conexao.BeginTransaction())
                {
                    try
                    {
                        SqlCommand comando = new SqlCommand();
                        comando.Connection = conexao;
                        comando.Transaction = trans;

                        comando.CommandText = "INSERT INTO Acao (Id, Nome) " +
                                              "              values(@Id, @Nome) ";

                        comando.Parameters.AddWithValue("Id", acao.Id);
                        comando.Parameters.AddWithValue("Nome", acao.Nome);
                        //comando.Parameters.AddWithValue("Preco", produto.Preco);
                        //comando.Parameters.AddWithValue("Quantidade", produto.Quantidade);

                        comando.ExecuteNonQuery();

                        trans.Commit();
                    }
                    catch (Exception ex)
                    {
                        trans.Rollback();
                    }
                }
            }
            return acao.Id;
        }

        public Acao Selecionar(Guid id)
        {
            Acao action = null;
            using (SqlConnection conexao = new SqlConnection(stringConexao))
            {
                conexao.Open();

                SqlCommand comando = new SqlCommand();
                comando.Connection = conexao;

                comando.CommandText = "SELECT Id, Nome FROM Acao WHERE id=@id";

                comando.Parameters.AddWithValue("id", id);

                SqlDataReader leitor = comando.ExecuteReader();

                while (leitor.Read())
                {
                    action = new Acao()
                    {
                        Id = Guid.Parse(leitor["Id"].ToString()),
                        Nome = leitor["Nome"].ToString(),
                        //Preco = Convert.ToDecimal(leitor["Preco"].ToString()),
                        //Quantidade = Convert.ToInt32(leitor["Quantidade"].ToString())
                    };
                }
            }
            return action;
        }
    }
}